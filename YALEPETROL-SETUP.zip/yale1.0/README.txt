								---------------------------------------
								YALE PETROL BENZİN İSTASYONU OTOMASYONU
								---------------------------------------


-Arda Can Uysal 
-215542007

-----------------otomasyon girişi----------------------

kullanıcı adı---> 1

şifre---> 1

---------------------KURULUM--------------------------

1-Adresi Belirtme

Setup içerisindeki Adres.txt dosyasını açıp;

Data Source= >-------------< ;Initial Catalog=Otomasyon;Integrated Security=True

>---------< kısma kendi adresinizi yapıştırın. Daha sonra Adres.txt dosyanızı kişisel bilgisayarınızdaki C: dizinine yapıştırın.

-----------------------------------------------------------
2-Veritabanına Erişme

Veritabanına erişmek için bilgisayarınızdaki 
******C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS\MSSQL\DATA*****
yoluna sql klasöründeki verileri kopyalayınız.


!!! Bu kısımda Hata vermesi durumunda kişisel bilgisayarınızda services.msc'de SQLEXPRESS'i durdurup,
 kopyalama işleminden sonra başlatmanızgerekmektedir.


------------------------------------------------------------
2-Veritabanını Microsoft SQL Server Management Studio’ya ekleme : 

Microsoft SQL Server Management Studio programını açıp Object Explorer menüsünden Databases'e sağ tıklayarak Attach>Add>Otomasyon.mdf 
seçerek veritabanını eklemiş oluyoruz.


------------------------------------------------------------

5-Programı kurma
Debug klasöründen Windows installer uzantılı REAOS_Setup2.0 çalıştır.
.
.
.
.
Daha Sonra programın kurulalcağı yolu seçerek next next diyerek devam ediyoruz.

------------------------------------------------------------

PROGRAM KURULDUKTAN SONRA 
 
Kullanıcı adı----> 1
Sifre---> 1

--------------------------------------------------_PROGRAM KURULDU_--------------------------------------------------------------